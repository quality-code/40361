﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CBN.Web.App.Startup))]
namespace CBN.Web.App
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
