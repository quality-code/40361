﻿const personUrlApi = 'https://randomuser.me/api/?results=3';

function createNode(element) {
    return document.createElement(element);
}

function append(parent,child) {
    return parent.appendChild(child);
}

async function getPersons() {    
    let response = await fetch(personUrlApi);
    if (response.ok) {
        const data = await response.json();
        let table = document.getElementById('PersonTable');
        data.results.map(function (d) {
            const tr = createNode('tr');
            const tdFullName = createNode('td');
            const tdPicture = createNode('td');
            const tdEmail = createNode('td');
            const img = createNode('img');

            tdFullName.innerHTML = d.name.title + ': ' + d.name.first + ' ' + d.name.last;
            img.src = d.picture.medium;
            tdEmail.innerHTML = d.email;

            append(tr, tdFullName);
            append(tdPicture, img);
            append(tr, tdPicture);
            append(tr, tdEmail);
            append(table, tr);
        });
    }
}