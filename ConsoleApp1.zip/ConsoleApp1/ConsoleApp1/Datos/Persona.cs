﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Datos
{
    class Persona
    {
        public event EventHandler Changed;

        public int Id { get; private set; }
        private string _nombre;

        public string Nombre
        {
            get { return $"Su nombre es: {_nombre} y tiene {_edad} años"; }
            private set { _nombre = value; }
        }


        private int _edad;

        public int Edad
        {
            get { return _edad; }
            set {
                _edad = value;
                Changed(this, EventArgs.Empty);

                
            }
        }


        public Persona(int id, string nombre)
        {
            Id = id;
            Nombre = nombre;
        }
        
        public string ObtenerNombre()
        {
            // Su Nombre es: Desarrollo y tiene 10 años
            var fullName1 = "Su Nombre es: " + this.Nombre + " y tiene " + this.Edad + " años";
            var fullName2 = string.Format("Su Nombre es: {0} y tiene {1} años", Nombre, Edad);
            var fullName3 = $"Su Nombre es: {Nombre} y tiene {Edad} años";

            return fullName3;
        }
    }
}
