﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Datos
{
    class Cliente
    {
        public static int id { get; set; }
        public static string ObtenerNombre()
        {
            return "CBN" + id;
        }
    }
}
