﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.Datos;
using CBN.POO;

namespace ConsoleApp1
{
    class Program
    {
        class Orden
        {
            public int Id { get; set; }
            public DateTime Fecha { get; set; }
            public string Vendedor { get; set; }
        }
        struct Factura
        {
            public int Id { get; set; }
            public DateTime Fecha { get; set; }
            public string Vendedor { get; set; }
        }
        static void Main(string[] args)
        {
            
            Estudiante estudiante = new Estudiante(123,"Juan",789,"Sistemas");
            Administrativo administrativo = new Administrativo(456,"Pedro","Jefe Sistemas");
            estudiante.Edad = 10;
            administrativo.Salario = 4000000;

            var result = estudiante.Guardar(administrativo);
            if (result is Estudiante)
            {

            }
            else if (result is Administrativo)
            {

            }

            //CiudadEspecial ciudad = new CiudadEspecial("CBN Santa Marta");
            //Console.WriteLine(ciudad.ObtenerNombre());
            //Factura o1, o2;
            //o1 = new Factura();
            //o2 = o1;
            //o1.Id = 123;
            //o2.Id = 456;
            //o1.Fecha = DateTime.Now;
            //
            //Console.WriteLine($"O2 {o2.Id} : O1 {o1.Id}");
            //Ejercicio3();
            //Console.WriteLine(Cliente.ObtenerNombre());
            
            Console.ReadKey();
        }

        private static void Ejercicio1()
        {
            var persona = new Persona(123,"Andres");
            persona.Edad = 28;

            Console.WriteLine(persona.ObtenerNombre());

            if (persona.Edad <= 18)
            {
                //JOVEN
                Console.WriteLine("Joven");
            }
            else if (persona.Edad <= 50)
            {
                //ADULTO
                Console.WriteLine("Adulto");
            }
            else
            {
                //ADULTO MAYOR
                Console.WriteLine("Adulto Mayor");
            }
        }
        private static void Ejercicio2()
        {
            var personas = new List<Persona>
            {
                new Persona(123,"abc"){ Edad = 10},
                new Persona(124,"xys"){ Edad = 20},
                new Persona(125,"dfg"){ Edad = 52}
            };

            foreach (var persona in personas)
            {
                Console.WriteLine(persona.ObtenerNombre());

                if (persona.Edad <= 18)
                {
                    //JOVEN
                    Console.WriteLine("Joven");
                }
                else if (persona.Edad <= 50)
                {
                    //ADULTO
                    Console.WriteLine("Adulto");
                }
                else
                {
                    //ADULTO MAYOR
                    Console.WriteLine("Adulto Mayor");
                }
            }            
        }
        private static void Ejercicio3()
        {
            try
            {
                //Abrimos la conexion a la BD
                //Insertamos info en la BD
                //Se genera la excepcion
                var persona = new Persona(123, "Juan");
                persona.Changed += Persona_Changed;
                persona.Edad = 23;
                Console.WriteLine(persona.Nombre);
            }
            catch (InvalidOperationException ex)
            {

            }
            catch (Exception ex)
            {
                //Se guarda en la tabla de auditori
            }
        }
        
        private static void Persona_Changed(object sender, EventArgs args)
        {
            var _edad = (sender as Persona).Edad;
            if (_edad <= 18)
            {
                Console.WriteLine("Joven");
            }
            else if (_edad <= 50)
            {
                Console.WriteLine("Adulto");
            }
            else
            {
                Console.WriteLine("Adulto Mayor");
            }
        }
    }
}
