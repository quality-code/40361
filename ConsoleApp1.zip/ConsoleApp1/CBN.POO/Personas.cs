﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBN.POO
{
    public abstract class Persona
    {
        protected int Id { get; set; }
        protected string Nombre { get; set; }
        public int Edad { get; set; }
        public float Altura { get; set; }
        public float Peso { get; set; }
        public Persona(int id, string nombre)
        {
            Id = id;
            Nombre = nombre;
        }
        public virtual Persona Guardar(Persona persona)
        {
            //Logica
            if (persona is Estudiante)
            {
                var estudiate = persona as Estudiante;
                estudiate.FechaIngreso = DateTime.Now;
            }
            else if (persona is Administrativo)
            {
                var administrativo = persona as Administrativo;
                administrativo.Salario = 4000000;
            }
            return null;
        }
    }
    public class Estudiante : Persona
    {
        protected int CodMatricula { get; set; }
        protected string Programa { get; set; }
        public DateTime FechaIngreso { get; set; }
        public Estudiante(int id, string nombre,int codMatricula, string programa) : base(id,nombre)
        {
            codMatricula = CodMatricula;
            Programa = programa;
        }
        public override Persona Guardar(Persona persona)
        {
            base.Guardar(persona);
            Estudiante estudiante = (Estudiante)persona;
            return estudiante;
        }
    }
    public class Administrativo : Persona
    {
        public double Salario { get; set; }
        protected string Cargo { get; set; }
        public Administrativo(int id, string nombre, string cargo) : base(id, nombre)
        {
            Cargo = cargo;
        }
        public override Persona Guardar(Persona persona)
        {
            Administrativo administrativo = persona as Administrativo;
            return administrativo;
        }
    }
    
}
