﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBN.POO
{
    class Pais
    {
        public Pais(int codigo,string nombre)
        {
            Codigo = codigo;
            Nombre = nombre;
        }
        private int Codigo { get; set; }
        private string Nombre { get; set; }
        public double Poblacion { get; set; }
        public List<Depto> Deptos { get; set; }
    }
    public class Depto
    {
        public Depto()
        {

        }
        public int Codigo { get; set; }
        public string Nombre { get; set; }
    }
    public class Ciudad
    {
        public Ciudad(string nombre)
        {
            Nombre = nombre;
        }
        protected string Nombre { get; set; }

        public string ObtenerNombre()
        {
            return "Su nombre es: " + Nombre;
        }
    }
    public class CiudadEspecial : Ciudad
    {
        public CiudadEspecial(string nombre) : base (nombre)
        {

        }
    }
}
