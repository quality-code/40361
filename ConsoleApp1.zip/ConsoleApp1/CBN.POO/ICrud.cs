﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBN.POO
{
    public interface ICrud<T>
    {
        T Get(int id);
        T GetList();
        int Post(T objectT);
        int Put(T objectT);
        bool Delete(T objectT);
    }
}
