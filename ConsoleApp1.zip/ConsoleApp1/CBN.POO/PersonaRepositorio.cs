﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBN.POO
{
    class PersonaRepositorio : ICrud<Estudiante>
    {
        public bool Delete(Estudiante objectT)
        {
            throw new NotImplementedException();
        }

        public Estudiante Get(int id)
        {
            throw new NotImplementedException();
        }

        public Estudiante GetList()
        {
            throw new NotImplementedException();
        }

        public int Post(Estudiante objectT)
        {
            throw new NotImplementedException();
        }

        public int Put(Estudiante objectT)
        {
            throw new NotImplementedException();
        }
    }
}
