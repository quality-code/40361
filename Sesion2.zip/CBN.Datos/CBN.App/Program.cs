﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBN.App
{
    class Program
    {
        static void Main(string[] args)
        {
            //ARRAY
            int[] lista;
            lista = new int[4];
            lista[0] = 3;
            lista[1] = 456;
            lista[2] = 789;
            lista[3] = 123;

            for (int i = 0; i < lista.Length; i++)
            {
                Console.WriteLine(lista[i]);
            }
            //QUEUE
            Console.WriteLine("Queue");
            Queue<int> listaInt = new Queue<int>();
            listaInt.Enqueue(456);
            listaInt.Enqueue(789);
            listaInt.Enqueue(123);
            listaInt.Enqueue(159);

            foreach (var item in listaInt)
            {
                Console.WriteLine(item);
            }

            listaInt.Dequeue();
            Console.WriteLine("Queue con Dequeue");
            foreach (var item in listaInt)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Queue con Peek");
            Console.WriteLine(listaInt.Peek());
            Console.WriteLine("Queue con Contains");
            Console.WriteLine(listaInt.Contains(159));

            //STACK
            Console.WriteLine("Stack");
            Stack<int> pila = new Stack<int>();

            pila.Push(789);
            pila.Push(654);
            pila.Push(852);
            pila.Push(357);

            foreach (var item in pila)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Stack con POP");
            pila.Pop();
            foreach (var item in pila)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Stack con PEEK");
            Console.WriteLine(pila.Peek());

            Console.WriteLine("Stack con CONTAINS");
            Console.WriteLine(pila.Contains(753));

            Console.ReadKey();

        }
    }
}
