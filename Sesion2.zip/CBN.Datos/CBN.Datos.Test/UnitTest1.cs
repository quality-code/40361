﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CBN.Datos.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ValidaLaSumaDe2Numeros()
        {
            //ARRANGE (Todo lo necesario para ejecutar mi Prueba)
            var operaciones = new CBN.Datos.Operaciones();
            var numA = 30;
            var numB = 50;
            var valEsperado = 70;
            //ACT (La ejecucion de la Prueba)
            var resultado = operaciones.Suma(numA, numB);
            //ASSERT (Validar el resultado de la Prueba)
            Assert.AreEqual(valEsperado, resultado);
        }
        [TestMethod]
        public void ValidaLaRestaDe2Numeros()
        {

        }
    }
}
